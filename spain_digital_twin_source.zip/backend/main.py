import os
import json
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import asyncio
import pandas as pd
import threading

app = FastAPI(title="Spain Digital Twin API")

# Enable CORS for the React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow all for local dev
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Paths to our processed data
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "processed")
PLANTS_FILE = os.path.join(DATA_DIR, "graphs", "plant_locations.json")
GEOJSON_FILE = os.path.join(DATA_DIR, "graphs", "spain_ccaa.geojson")

# Global state for dynamic digital twin visualization
grid_state = {
    "initialized": False,
    "plants": {},
    "regions": {},
    "edges": []
}

def init_state():
    """Initializes the global grid state with plants and regions."""
    if grid_state["initialized"]:
        return
        
    plants = {}
    if os.path.exists(PLANTS_FILE):
        with open(PLANTS_FILE, 'r', encoding='utf-8') as f:
            plants = json.load(f)
            
    # Filter out plants that failed geocoding and add status
    valid_plants = {}
    for k, v in plants.items():
        if v.get("lat") is not None:
            valid_plants[k] = {**v, "status": "online"}
    grid_state["plants"] = valid_plants
    
    regions = {}
    if os.path.exists(GEOJSON_FILE):
        import shapely.geometry as sg
        with open(GEOJSON_FILE, 'r', encoding='utf-8') as f:
            geojson = json.load(f)
            
        for feature in geojson.get("features", []):
            try:
                name = feature["properties"]["name"]
                geom = sg.shape(feature["geometry"])
                centroid = geom.centroid
                regions[name] = {"lon": centroid.x, "lat": centroid.y, "supplied_by": None}
            except Exception:
                pass
    grid_state["regions"] = regions
    
    # Calculate initial edges (plant to nearest region)
    recalculate_routing()
    grid_state["initialized"] = True

def recalculate_routing():
    """Recalculates supply mapping from regions to the nearest online plant."""
    edges = []
    plants = grid_state["plants"]
    regions = grid_state["regions"]
    
    for r_name, r_data in regions.items():
        best_plant = None
        best_dist = float('inf')
        
        for p_id, p_data in plants.items():
            if p_data["status"] == "offline":
                continue # Skip failed plants
                
            dist = (p_data['lon'] - r_data['lon'])**2 + (p_data['lat'] - r_data['lat'])**2
            if dist < best_dist:
                best_dist = dist
                best_plant = p_id
                
        if best_plant:
            regions[r_name]["supplied_by"] = best_plant
            edges.append({
                "source": best_plant,
                "target": r_name,
                "source_pos": [plants[best_plant]['lon'], plants[best_plant]['lat']],
                "target_pos": [r_data['lon'], r_data['lat']],
                "is_rerouted": False # Initial routes are not considered rerouted
            })
            
    grid_state["edges"] = edges

@app.get("/")
def read_root():
    return {"status": "ok", "message": "Spain Digital Twin API is running"}

@app.get("/api/topology")
def get_topology():
    """Returns the current dynamic topology."""
    if not grid_state["initialized"]:
        init_state()
        
    return {
        "nodes": {
            "plants": grid_state["plants"]
        },
        "edges": grid_state["edges"]
    }

@app.get("/api/regions")
def get_regions():
    """Returns the GeoJSON for the Spanish Autonomous Communities."""
    if not os.path.exists(GEOJSON_FILE):
        raise HTTPException(status_code=404, detail="GeoJSON not found")
        
    with open(GEOJSON_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

@app.post("/api/simulate/chaos")
async def trigger_chaos(target_id: str):
    """Triggers a failure in the simulation engine and reroutes power."""
    if not grid_state["initialized"]:
        init_state()
        
    if target_id not in grid_state["plants"]:
        raise HTTPException(status_code=404, detail="Plant not found")
        
    # 1. Mark plant offline
    grid_state["plants"][target_id]["status"] = "offline"
    
    # 2. Reroute
    old_edges = { (e["source"], e["target"]) for e in grid_state["edges"] }
    recalculate_routing()
    
    # 3. Mark newly created edges as rerouted
    for edge in grid_state["edges"]:
        if (edge["source"], edge["target"]) not in old_edges:
            edge["is_rerouted"] = True
            
    return {
        "status": "chaos_injected",
        "target": target_id,
        "topology": {
            "nodes": {
                "plants": grid_state["plants"]
            },
            "edges": grid_state["edges"]
        }
    }

# ─────────────────────────────────────────────────────────
#  CHAOS ENGINE API ENDPOINTS
# ─────────────────────────────────────────────────────────

# Global chaos engine state
chaos_state = {
    "engine": None,
    "initial_state": None,
    "initialized": False,
}

def get_chaos_engine():
    """Lazily initialize the chaos engine with a demo grid state."""
    if chaos_state["initialized"]:
        return chaos_state["engine"]
    
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from digital_twin.simulator import ChaosEngine, build_demo_grid_state
    
    initial = build_demo_grid_state()
    chaos_state["initial_state"] = initial
    chaos_state["engine"] = ChaosEngine(initial)
    chaos_state["initialized"] = True
    print("[Backend] Chaos Engine initialized with demo grid state.")
    return chaos_state["engine"]


class GeneratorFailureRequest(BaseModel):
    generator_id: str

@app.post("/api/chaos/generator")
async def chaos_generator(req: GeneratorFailureRequest):
    """Trip a specific generator offline."""
    try:
        engine = get_chaos_engine()
        event = engine.inject_generator_failure(req.generator_id)
        return {
            "status": "success",
            "event": {"description": event.description, "impact_mw": event.impact_mw},
            "grid_summary": engine.state.summary(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


class RenewableShockRequest(BaseModel):
    fuel_type: str
    reduction_pct: float

@app.post("/api/chaos/renewable-shock")
async def chaos_renewable_shock(req: RenewableShockRequest):
    """Reduce all generators of a renewable type by a percentage."""
    try:
        engine = get_chaos_engine()
        event = engine.inject_renewable_shock(req.fuel_type, req.reduction_pct)
        return {
            "status": "success",
            "event": {"description": event.description, "impact_mw": event.impact_mw},
            "grid_summary": engine.state.summary(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


class DemandSurgeRequest(BaseModel):
    region: str
    increase_pct: float

@app.post("/api/chaos/demand-surge")
async def chaos_demand_surge(req: DemandSurgeRequest):
    """Spike demand in a specific region."""
    try:
        engine = get_chaos_engine()
        event = engine.inject_demand_surge(req.region, req.increase_pct)
        return {
            "status": "success",
            "event": {"description": event.description, "impact_mw": event.impact_mw},
            "grid_summary": engine.state.summary(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


class CascadeRequest(BaseModel):
    max_depth: int = 10

@app.post("/api/chaos/cascade")
async def chaos_cascade(req: CascadeRequest):
    """Run a full cascading failure simulation on the current grid state."""
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from digital_twin.cascade import CascadeEngine

    engine = get_chaos_engine()
    cascade = CascadeEngine(engine)
    result = cascade.run_cascade(
        initial_trigger="API-triggered cascade",
        max_depth=req.max_depth,
    )
    return {
        "status": "success",
        "cascade": cascade.to_dict(result),
        "grid_summary": engine.state.summary(),
    }


class RandomChaosRequest(BaseModel):
    n_failures: int = 1

@app.post("/api/chaos/random")
async def chaos_random(req: RandomChaosRequest):
    """Random chaos monkey — trip N random components."""
    engine = get_chaos_engine()
    events = engine.run_random_chaos(n_failures=req.n_failures)
    return {
        "status": "success",
        "events": [{"description": e.description, "impact_mw": e.impact_mw} for e in events],
        "grid_summary": engine.state.summary(),
    }


@app.post("/api/chaos/reset")
async def chaos_reset():
    """Restore the grid to its initial pre-chaos state."""
    engine = get_chaos_engine()
    engine.reset()
    return {
        "status": "reset",
        "grid_summary": engine.state.summary(),
    }


@app.get("/api/resilience")
async def get_resilience():
    """Calculate the current grid resilience score with full breakdown."""
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from digital_twin.metrics import calculate_resilience_score

    engine = get_chaos_engine()
    initial = chaos_state["initial_state"]
    
    # Get cascade info if available
    cascade_depth = 0
    cascade_size = 0
    geo_spread = 0
    if engine.cascade_log:
        last = engine.cascade_log[-1]
        cascade_depth = last.get("cascade_depth", 0)
        cascade_size = last.get("cascade_size", 0)
    
    score = calculate_resilience_score(
        initial, engine.state,
        cascade_depth=cascade_depth,
        cascade_size=cascade_size,
        geographic_spread=geo_spread,
    )
    return {
        "resilience": score,
        "grid_summary": engine.state.summary(),
        "event_log": engine.get_event_log(),
    }


class WhatIfRequest(BaseModel):
    scenario_type: str  # "renewable_shock", "demand_surge", "generator_failure"
    target: str = ""
    value: float = 50.0

@app.post("/api/whatif")
async def what_if(req: WhatIfRequest):
    """Compare grid state before and after a scenario without permanently changing state."""
    import copy
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from digital_twin.simulator import ChaosEngine
    from digital_twin.metrics import calculate_resilience_score
    from digital_twin.redispatch import RedispatchEngine

    engine = get_chaos_engine()
    
    # Create a temporary copy to run the what-if on
    temp_engine = ChaosEngine(copy.deepcopy(engine.state))
    before = temp_engine.state.summary()
    
    # Run the scenario on the temp copy
    if req.scenario_type == "renewable_shock":
        temp_engine.inject_renewable_shock(req.target or "Wind", req.value)
    elif req.scenario_type == "demand_surge":
        temp_engine.inject_demand_surge(req.target or "Madrid", req.value)
    elif req.scenario_type == "generator_failure":
        temp_engine.inject_generator_failure(req.target)
    else:
        raise HTTPException(status_code=400, detail=f"Unknown scenario type: {req.scenario_type}")
    
    after = temp_engine.state.summary()
    
    # Calculate resilience for both states
    initial = chaos_state["initial_state"]
    score_before = calculate_resilience_score(initial, engine.state)
    score_after = calculate_resilience_score(initial, temp_engine.state)
    
    # Estimate redispatch cost
    redispatch = RedispatchEngine()
    cost_estimate = redispatch.estimate_redispatch_cost(temp_engine.state)
    
    return {
        "before": before,
        "after": after,
        "resilience_before": score_before,
        "resilience_after": score_after,
        "redispatch_cost": cost_estimate,
        "deltas": {
            k: round(after[k] - before[k], 2) 
            for k in before 
            if isinstance(before[k], (int, float))
        },
    }


# Forecast Engine Global State
forecast_state = {
    "model": None,
    "dataset": None,
    "date_to_idx": {},
    "initialized": False
}
forecast_engine_lock = threading.Lock()

def get_forecast_engine():
    if forecast_state["initialized"]:
        return forecast_state
        
    with forecast_engine_lock:
        # Double-check inside lock
        if forecast_state["initialized"]:
            return forecast_state
            
        import sys
        sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), "forecasting"))
        import torch
        from dataset import SpainElectricityDataset
        from gnn import GATForecaster
        from hybrid_corrector import HybridCorrector
        
        print("[Backend] Initializing ML/DL Hybrid Forecasting Engine...", flush=True)
        project_root = os.path.dirname(os.path.dirname(__file__))
    data_dir = os.path.join(project_root, "data")
    dataset = SpainElectricityDataset(split="test", year_start=2020, year_end=2027, data_dir=data_dir)
    val_dataset = SpainElectricityDataset(split="val", year_start=2020, year_end=2027, data_dir=data_dir)
    
    in_channels = 15
    hidden_channels = 64
    pred_horizon = 24
    
    base_dir = os.path.dirname(os.path.dirname(__file__))
    asym_path = os.path.join(base_dir, "data", "models", "best_gat_forecaster_asymmetric.pth")
    hol_path = os.path.join(base_dir, "data", "models", "best_gat_forecaster_holiday.pth")
    corrector_path = os.path.join(base_dir, "data", "models", "hybrid_corrector.pkl")
    
    # Try to load both models for ensemble
    model_asym = None
    model_hol = None
    
    for path, name in [(asym_path, "asymmetric"), (hol_path, "holiday")]:
        if os.path.exists(path):
            try:
                m = GATForecaster(in_channels, hidden_channels, 1, pred_horizon, heads=4)
                ck = torch.load(path, map_location="cpu")
                m.load_state_dict(ck['state_dict'] if isinstance(ck, dict) and 'state_dict' in ck else ck)
                m.eval()
                if name == "asymmetric":
                    model_asym = m
                else:
                    model_hol = m
                print(f"[Backend] Loaded {name} model from {path}")
            except Exception as e:
                print(f"[Backend] Could not load {name} model: {e}")
    
    # Build hybrid if both models available, else fall back
    if model_asym is not None and model_hol is not None:
        hybrid = HybridCorrector(model_asym, model_hol, dataset)
        if os.path.exists(corrector_path):
            hybrid.load_correctors(corrector_path)
        else:
            print("[Backend] Warning: hybrid_corrector.pkl not found! Training on the fly...")
            hybrid.fit(dataset, val_dataset, max_train=500, max_val=100) # fast train
        
        forecast_state["hybrid"] = hybrid
        forecast_state["model"] = model_asym  # fallback reference
        print("[Backend] ML/DL Hybrid Corrector ready")
    elif model_asym is not None:
        forecast_state["model"] = model_asym
        print("[Backend] Running with asymmetric model only (no ensemble)")
    elif model_hol is not None:
        forecast_state["model"] = model_hol
        print("[Backend] Running with holiday model only (no ensemble)")
    else:
        print("[Backend] WARNING: No model weights found!")
    
    # Precompute date to index lookup
    date_to_idx = {}
    if hasattr(dataset, "time_idx"):
        for idx in range(len(dataset)):
            dt = pd.to_datetime(dataset.time_idx[idx + dataset.seq_length])
            d_str = dt.strftime("%Y-%m-%d")
            if d_str not in date_to_idx:
                date_to_idx[d_str] = idx
                
    forecast_state["dataset"] = dataset
    forecast_state["date_to_idx"] = date_to_idx
    forecast_state["initialized"] = True
    print(f"[Backend] Forecasting engine ready with {len(date_to_idx)} test dates.")
    return forecast_state

@app.get("/api/forecast")
def get_forecast(date: str, region: str):
    """
    Returns 24-hour forecast vs actual data for a specific date and region
    using the trained 15-channel ML/DL Hybrid GAT forecaster.
    """
    try:
        import sys
        sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), "forecasting"))
        import torch
        import numpy as np
        import pandas as pd
        
        engine = get_forecast_engine()
        dataset = engine["dataset"]
        model = engine["model"]
        date_to_idx = engine["date_to_idx"]
        
        FRONTEND_TO_IDX = {
            'Andalucía': 0, 'Aragón': 1, 'Cantabria': 2, 'Castilla - La Mancha': 3, 
            'Castilla y León': 4, 'Cataluña': 5, 'País Vasco': 6, 'Principado de Asturias': 7, 
            'Ceuta': 8, 'Melilla': 9, 'Comunidad de Madrid': 10, 'Comunidad Foral de Navarra': 11,
            'Comunitat Valenciana': 12, 'Extremadura': 13, 'Galicia': 14, 'Illes Balears': 15,
            'Canarias': 16, 'La Rioja': 17, 'Región de Murcia': 18
        }
        region_idx = FRONTEND_TO_IDX.get(region, 0)
            
        # Find index for date or closest available
        if date in date_to_idx:
            idx = date_to_idx[date]
        else:
            # Fallback to index based on hash or latest available
            if len(date_to_idx) > 0:
                available_dates = list(date_to_idx.keys())
                # Pick closest date
                try:
                    target_dt = pd.to_datetime(date)
                    dts = pd.to_datetime(available_dates)
                    closest_idx = np.argmin(np.abs((dts - target_dt).total_seconds()))
                    idx = date_to_idx[available_dates[closest_idx]]
                except Exception:
                    idx = len(dataset) // 2
            else:
                idx = 0
                
        idx = min(idx, len(dataset) - 1)
        
        x, y_true, y_holiday = dataset[idx]
        x_batch = x.unsqueeze(0)
        
        with torch.no_grad():
            hybrid = engine.get("hybrid", None)
            if hybrid is not None:
                # ML/DL Hybrid: GBT corrects GAT raw outputs
                y_pred = hybrid.predict(x_batch, dataset.edge_index, dataset.edge_weight, target_date=date)
            else:
                y_pred = model(x_batch, dataset.edge_index, dataset.edge_weight).squeeze(0)
            
        actual_scaled = y_true[region_idx].numpy()
        pred_scaled = y_pred[region_idx].numpy()
        
        # Inverse transform using dataset scaler
        def inv_transform(scaled_array, node_idx):
            num_scaled = dataset.num_scaled_features
            dummy = np.zeros((24, num_scaled))
            dummy[:, 0] = scaled_array
            return dataset.scaler.inverse_transform(dummy, node_idx=node_idx)[:, 0]
            
        actual_mw = inv_transform(actual_scaled, region_idx)
        pred_mw = inv_transform(pred_scaled, region_idx)
        
        # Build hourly response
        hourly_data = []
        for h in range(24):
            hourly_data.append({
                "hour": h,
                "actual_mw": round(float(max(0, actual_mw[h])), 1),
                "predicted_mw": round(float(max(0, pred_mw[h])), 1)
            })
            
        # Calculate daily aggregate & weekly distribution
        day_total = float(sum(max(0, v) for v in actual_mw))
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        factors = [1.02, 1.05, 1.03, 1.01, 1.08, 0.85, 0.78]
        weekly_consumption = [
            {"day": d, "consumption": round(day_total * f, 0)} for d, f in zip(days, factors)
        ]
        
        return {
            "region": dataset.node_names[region_idx],
            "date": date,
            "hourly_data": hourly_data,
            "weekly_consumption": weekly_consumption
        }
    except Exception as e:
        print(f"Error in forecast API: {e}")
        import traceback; traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/forecast/hover")
def get_forecast_hover(date: str, region: str):
    """Quick hover prediction — returns next hour + next day aggregate MW."""
    try:
        import torch
        import numpy as np
        
        engine = get_forecast_engine()
        dataset = engine["dataset"]
        model = engine["model"]
        date_to_idx = engine["date_to_idx"]
        
        UI_MAP = {
            'Andalucía': 'Andalucía', 'Aragón': 'Aragón', 'Principado de Asturias': 'Principado de Asturias',
            'Illes Balears': 'Islas Baleares', 'Canarias': 'Islas Canarias', 'Cantabria': 'Cantabria',
            'Castilla y León': 'Castilla y León', 'Castilla - La Mancha': 'Castilla la Mancha', 'Cataluña': 'Cataluña',
            'Comunitat Valenciana': 'Comunidad Valenciana', 'Extremadura': 'Extremadura', 'Galicia': 'Galicia',
            'Comunidad de Madrid': 'Comunidad de Madrid', 'Región de Murcia': 'Región de Murcia',
            'Comunidad Foral de Navarra': 'Comunidad de Navarra', 'País Vasco': 'País Vasco', 'La Rioja': 'La Rioja',
            'Ceuta': 'Comunidad de Ceuta', 'Melilla': 'Comunidad de Melilla'
        }
        dataset_node = UI_MAP.get(region, region)
        region_idx = 0
        for i, name in enumerate(dataset.node_names):
            if name == dataset_node:
                region_idx = i
                break
        
        if date in date_to_idx:
            idx = date_to_idx[date]
        else:
            available = list(date_to_idx.keys())
            if available:
                target_dt = pd.to_datetime(date)
                dts = pd.to_datetime(available)
                closest = int(np.argmin(np.abs((dts - target_dt).total_seconds())))
                idx = date_to_idx[available[closest]]
            else:
                idx = 0
        idx = min(idx, len(dataset) - 1)
        
        x, y_true, _ = dataset[idx]
        # Force everything to CPU to avoid cuda/cpu device mismatch
        x_batch = x.unsqueeze(0).cpu()
        edge_index = dataset.edge_index.cpu()
        edge_weight = dataset.edge_weight.cpu()
        
        with torch.no_grad():
            hybrid = engine.get("hybrid", None)
            if hybrid is not None:
                # Use hybrid corrector (same path as /api/forecast)
                y_pred = hybrid.predict(x_batch, edge_index, edge_weight, target_date=date)
            else:
                model_cpu = model.cpu() if model is not None else None
                if model_cpu is None:
                    raise RuntimeError("No model loaded")
                y_pred = model_cpu(x_batch, edge_index, edge_weight).squeeze(0)
        
        # Ensure output is on CPU
        if hasattr(y_pred, 'cpu'):
            y_pred = y_pred.cpu()
        
        pred_scaled = y_pred[region_idx].numpy()
        actual_scaled = y_true[region_idx].numpy()
        
        def inv_transform(arr, node_idx):
            ns = dataset.num_scaled_features
            d = np.zeros((24, ns))
            d[:, 0] = arr
            return dataset.scaler.inverse_transform(d, node_idx=node_idx)[:, 0]
        
        pred_mw = inv_transform(pred_scaled, region_idx)
        actual_mw = inv_transform(actual_scaled, region_idx)
        
        return {
            "region": dataset.node_names[region_idx],
            "next_hour_predicted_mw": round(float(max(0, pred_mw[0])), 1),
            "next_hour_actual_mw": round(float(max(0, actual_mw[0])), 1),
            "next_day_predicted_mw": round(float(sum(max(0, v) for v in pred_mw)), 1),
            "next_day_actual_mw": round(float(sum(max(0, v) for v in actual_mw)), 1),
            "peak_predicted_mw": round(float(max(0, float(max(pred_mw)))), 1),
        }
    except Exception as e:
        print(f"Hover forecast error: {e}")
        import traceback; traceback.print_exc()
        return {"region": region, "next_hour_predicted_mw": 0, "next_day_predicted_mw": 0, "peak_predicted_mw": 0}


@app.get("/api/forecast/weekend")
def get_forecast_weekend(date: str, region: str):
    """Returns 48-hour forecast (Sat + Sun) for the weekend containing the given date."""
    try:
        import torch
        import numpy as np
        
        engine = get_forecast_engine()
        dataset = engine["dataset"]
        model = engine["model"]
        date_to_idx = engine["date_to_idx"]
        
        UI_MAP = {
            'Andalucía': 'Andalucía', 'Aragón': 'Aragón', 'Principado de Asturias': 'Principado de Asturias',
            'Illes Balears': 'Islas Baleares', 'Canarias': 'Islas Canarias', 'Cantabria': 'Cantabria',
            'Castilla y León': 'Castilla y León', 'Castilla - La Mancha': 'Castilla la Mancha', 'Cataluña': 'Cataluña',
            'Comunitat Valenciana': 'Comunidad Valenciana', 'Extremadura': 'Extremadura', 'Galicia': 'Galicia',
            'Comunidad de Madrid': 'Comunidad de Madrid', 'Región de Murcia': 'Región de Murcia',
            'Comunidad Foral de Navarra': 'Comunidad de Navarra', 'País Vasco': 'País Vasco', 'La Rioja': 'La Rioja',
            'Ceuta': 'Comunidad de Ceuta', 'Melilla': 'Comunidad de Melilla'
        }
        dataset_node = UI_MAP.get(region, region)
        region_idx = 0
        for i, name in enumerate(dataset.node_names):
            if name == dataset_node:
                region_idx = i
                break
        
        # Find Saturday of the week containing this date
        target_dt = pd.to_datetime(date)
        days_to_sat = (5 - target_dt.weekday()) % 7
        if target_dt.weekday() == 6:  # Sunday
            saturday = target_dt - pd.Timedelta(days=1)
        else:
            saturday = target_dt + pd.Timedelta(days=days_to_sat)
        sunday = saturday + pd.Timedelta(days=1)
        
        sat_str = saturday.strftime("%Y-%m-%d")
        sun_str = sunday.strftime("%Y-%m-%d")
        
        # Force graph tensors to CPU once (they may be on CUDA if hybrid init moved them)
        edge_index = dataset.edge_index.cpu()
        edge_weight = dataset.edge_weight.cpu()
        hybrid = engine.get("hybrid", None)
        
        def get_day_data(day_str):
            if day_str in date_to_idx:
                idx = date_to_idx[day_str]
            else:
                available = list(date_to_idx.keys())
                if available:
                    dt = pd.to_datetime(day_str)
                    dts = pd.to_datetime(available)
                    closest = int(np.argmin(np.abs((dts - dt).total_seconds())))
                    idx = date_to_idx[available[closest]]
                else:
                    idx = 0
            idx = min(idx, len(dataset) - 1)
            
            x, y_true, _ = dataset[idx]
            x_batch = x.unsqueeze(0).cpu()
            
            with torch.no_grad():
                if hybrid is not None:
                    y_pred = hybrid.predict(x_batch, edge_index, edge_weight, target_date=day_str)
                else:
                    y_pred = model.cpu()(x_batch, edge_index, edge_weight).squeeze(0)
            
            if hasattr(y_pred, 'cpu'):
                y_pred = y_pred.cpu()
            
            pred_scaled = y_pred[region_idx].numpy()
            actual_scaled = y_true[region_idx].numpy()
            
            def inv_transform(arr, node_idx):
                ns = dataset.num_scaled_features
                d = np.zeros((24, ns))
                d[:, 0] = arr
                return dataset.scaler.inverse_transform(d, node_idx=node_idx)[:, 0]
            
            return inv_transform(actual_scaled, region_idx), inv_transform(pred_scaled, region_idx)
        
        sat_actual, sat_pred = get_day_data(sat_str)
        sun_actual, sun_pred = get_day_data(sun_str)
        
        hourly_data = []
        for h in range(24):
            hourly_data.append({
                "hour": f"Sat {h}h",
                "actual_mw": round(float(max(0, sat_actual[h])), 1),
                "predicted_mw": round(float(max(0, sat_pred[h])), 1)
            })
        for h in range(24):
            hourly_data.append({
                "hour": f"Sun {h}h",
                "actual_mw": round(float(max(0, sun_actual[h])), 1),
                "predicted_mw": round(float(max(0, sun_pred[h])), 1)
            })
        
        return {
            "region": dataset.node_names[region_idx],
            "saturday": sat_str,
            "sunday": sun_str,
            "hourly_data": hourly_data,
        }
    except Exception as e:
        print(f"Weekend forecast error: {e}")
        import traceback; traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/forecast/dates")
def get_forecast_dates():
    """
    Returns the sorted list of all available test-set dates that the model
    can generate forecasts for. Used by the DateNavigator in the frontend.
    """
    try:
        engine = get_forecast_engine()
        dates = sorted(engine["date_to_idx"].keys())
        return {"dates": dates, "count": len(dates)}
    except Exception as e:
        print(f"Dates endpoint error: {e}")
        import traceback; traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/forecast/all-regions")
def get_all_regions_forecast(date: str):
    """
    Runs a single forward pass for the given date and returns predicted peak MW
    and total predicted MWh for every region. Used to colour the Spain map
    as a heat-map of predicted energy demand.
    """
    try:
        import sys
        sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), "forecasting"))
        import torch
        import numpy as np
        import pandas as pd

        engine = get_forecast_engine()
        dataset = engine["dataset"]
        model = engine["model"]
        date_to_idx = engine["date_to_idx"]

        # Resolve dataset index
        if date in date_to_idx:
            idx = date_to_idx[date]
        else:
            available = list(date_to_idx.keys())
            if available:
                target_dt = pd.to_datetime(date)
                dts = pd.to_datetime(available)
                closest = int(np.argmin(np.abs((dts - target_dt).total_seconds())))
                idx = date_to_idx[available[closest]]
            else:
                idx = 0
        idx = min(idx, len(dataset) - 1)

        x, y_true, _ = dataset[idx]
        x_batch = x.unsqueeze(0)

        with torch.no_grad():
            hybrid = engine.get("hybrid", None)
            if hybrid is not None:
                y_pred = hybrid.predict(x_batch, dataset.edge_index, dataset.edge_weight, target_date=date)
            else:
                y_pred = model(x_batch, dataset.edge_index, dataset.edge_weight).squeeze(0)

        # Node names match dataset order
        NODE_NAMES = dataset.node_names  # list of 19 region strings

        # Frontend UI name -> dataset index mapping (mirrors the /api/forecast mapping)
        UI_MAP = {
            'Andaluc\u00eda': 'Andaluc\u00eda',
            'Arag\u00f3n': 'Arag\u00f3n',
            'Principado de Asturias': 'Principado de Asturias',
            'Illes Balears': 'Islas Baleares',
            'Canarias': 'Islas Canarias',
            'Cantabria': 'Cantabria',
            'Castilla y Le\u00f3n': 'Castilla y Le\u00f3n',
            'Castilla - La Mancha': 'Castilla la Mancha',
            'Catalu\u00f1a': 'Catalu\u00f1a',
            'Comunitat Valenciana': 'Comunidad Valenciana',
            'Extremadura': 'Extremadura',
            'Galicia': 'Galicia',
            'Comunidad de Madrid': 'Comunidad de Madrid',
            'Regi\u00f3n de Murcia': 'Regi\u00f3n de Murcia',
            'Comunidad Foral de Navarra': 'Comunidad de Navarra',
            'Pa\u00eds Vasco': 'Pa\u00eds Vasco',
            'La Rioja': 'La Rioja',
            'Ceuta': 'Comunidad de Ceuta',
            'Melilla': 'Comunidad de Melilla',
        }
        # Reverse: dataset_name -> node_idx
        name_to_idx = {n: i for i, n in enumerate(NODE_NAMES)}

        def inv_transform(scaled_array, node_idx):
            ns = dataset.num_scaled_features
            dummy = np.zeros((24, ns))
            dummy[:, 0] = scaled_array
            return dataset.scaler.inverse_transform(dummy, node_idx=node_idx)[:, 0]

        result = {}
        for ui_name, dataset_name in UI_MAP.items():
            node_idx = name_to_idx.get(dataset_name)
            if node_idx is None:
                result[ui_name] = {"peak_predicted_mw": 0, "total_predicted_mwh": 0, "peak_actual_mw": 0}
                continue

            pred_scaled = y_pred[node_idx].numpy()
            actual_scaled = y_true[node_idx].numpy()

            pred_mw = inv_transform(pred_scaled, node_idx)
            actual_mw = inv_transform(actual_scaled, node_idx)

            result[ui_name] = {
                "peak_predicted_mw": round(float(max(0, float(np.max(pred_mw)))), 1),
                "total_predicted_mwh": round(float(sum(max(0, float(v)) for v in pred_mw)), 1),
                "peak_actual_mw": round(float(max(0, float(np.max(actual_mw)))), 1),
            }

        return {"date": date, "regions": result}
    except Exception as e:
        print(f"All-regions forecast error: {e}")
        import traceback; traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

