---
tags: [data, schema]
---
# Data Dictionary

This document enforces the data structures we use, preventing the AI from hallucinating column names or shapes.

## 1. Processed Weather Data
**Location:** `data/processed/weather/*.csv` (Also duplicated in `data/excel/weather/`)
**Format:** 1 CSV per region.
**Rows:** 96,432 (2015-01-01 to 2025-12-31, hourly)
**Columns:**
- `region`: String (e.g. 'Andalucia')
- `datetime`: ISO-8601 string (e.g. '2015-01-01T00:00')
- `temperature_2m`: Float (°C)
- `relative_humidity_2m`: Float (%)
- `wind_speed_10m`: Float (km/h)
- `shortwave_radiation`: Float (W/m²)

## 2. Spatial Graphs
**Location:** `data/processed/graphs/`
- `node_ids.csv`: Maps integer index `[0-18]` to Region string and lat/lon.
- `A_geo.npy`: 19x19 float matrix. Geographic adjacency via Haversine distance and Gaussian kernel (sigma=200km).
- `A_elec.npy`: 19x19 float matrix. Electrical adjacency (binary). 1 = connected by land border or HVDC cable.

## 3. Processed Demand Data (PENDING)
**Location:** `data/processed/demand/*.csv`
*(Currently holds corrupted/monthly data. Waiting for e-sios token to fetch proper hourly data).*

## 4. Power Plant & Generation Data (PENDING)
**Location:** `data/processed/generation/`
*(Will be populated by ENTSO-E API once token is provided).*
- `installed_capacity_ES_*.csv`: The MW capacity of different technologies in Spain.
- `aggregated_generation_ES_*.csv`: Hourly MW output by generation type (Wind, Solar, Gas, etc.).
- `unit_generation_ES_*.csv`: Plant-level telemetry. The core input for the Chaos Engine to simulate specific generator failures.
