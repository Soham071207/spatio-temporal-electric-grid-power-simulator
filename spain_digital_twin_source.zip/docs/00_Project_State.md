---
tags: [dashboard, moc, index]
---
# Project State Dashboard

This file serves as the single source of truth for the AI assistant to instantly understand the current state of the project without needing to read the entire chat history. 

## Current Status
- **Current Phase:** P2 (Digital Twin & Architecture) - Integrating Backend, Frontend, and Chaos Engine.
- **Data Acquisition:** 
  - ENTSO-E token added. Background task currently fetching 11 years (2015-2025) of hourly plant-level generation data.
- **Backend:** 
  - FastAPI server implemented (`backend/main.py`).
  - Maintains global `grid_state`.
  - Exposes endpoints: `/api/topology`, `/api/regions`, `/api/simulate/chaos`.
  - Performs real-time greedy allocation to route MW from power plants to regions.
- **Frontend:** 
  - React + DeckGL frontend built (`frontend/src/App.jsx`).
  - Premium dark-blue UI theme with real-time HUD and event log.
  - 3D rendering: GeoJSON Regions (Dark Blue), SimpleMeshLayer (Upside-down spinning cones for plants), ScatterplotLayer (Green overlap radius circles), ArcLayer (Power flow lines, Red/Orange on reroute).
- **Next Action:** 
  1. Once ENTSO-E downloading finishes, ingest the `.csv` data into the backend.
  2. Implement the Spatio-Temporal Graph Neural Network (ST-GNN) as a surrogate simulator.

## Quick Links
- [[10_Architecture]]: System architecture, tech stack, and component interactions.
- [[20_Data_Dictionary]]: Schema for all data files.
- [[30_Decisions_Log]]: Critical decisions made during the project.

## AI Memory Anchors
- **Workspace Root:** `c:\Users\soham\Desktop\edi-1`
- **Data Target:** Spain (Regional for demand, Plant-level for generation).
- **Core Model:** Spatio-Temporal Graph Neural Network (ST-GNN) acting as a surrogate simulator.
- **Goal:** Digital Twin capable of resilience scoring via Chaos Engineering (Synthetic failures).
