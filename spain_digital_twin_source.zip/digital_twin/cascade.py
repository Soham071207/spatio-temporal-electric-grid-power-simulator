"""
Cascading Failure Engine — Dedicated cascade propagation logic.

Tracks overloaded lines after each fault, auto-trips lines exceeding capacity,
redistributes power flows, and logs cascade depth/size/geographic spread.
"""

from typing import List, Dict, Optional
from dataclasses import dataclass, field
from .simulator import GridState, ChaosEngine, TransmissionLine


@dataclass
class CascadeStep:
    """Records one step in a cascading failure sequence."""
    depth: int
    tripped_lines: List[str]
    tripped_generators: List[str]
    overloaded_lines_before: int
    overloaded_lines_after: int
    total_generation_mw: float
    total_demand_mw: float
    deficit_mw: float
    frequency_hz: float
    affected_regions: List[str]


@dataclass
class CascadeResult:
    """Full result of a cascade simulation."""
    initial_trigger: str
    cascade_depth: int = 0
    cascade_size: int = 0           # Total components lost
    steps: List[CascadeStep] = field(default_factory=list)
    affected_regions: List[str] = field(default_factory=list)
    geographic_spread: int = 0      # Number of unique regions affected
    final_deficit_mw: float = 0.0
    final_frequency_hz: float = 50.0
    total_load_lost_mw: float = 0.0
    total_generation_lost_mw: float = 0.0
    system_stable: bool = True
    blackout: bool = False
    recovery_actions: List[str] = field(default_factory=list)


class CascadeEngine:
    """
    Dedicated cascade propagation engine.

    Section 5 of the chaos engineering doc:
      Line A fails → Power transfers to Line B → Line B overloaded →
      Line B trips → Power transfers to C/D → Voltage instability →
      Generator trips → Regional imbalance → CASCADE
    """

    def __init__(self, engine: ChaosEngine):
        self.engine = engine
        self.state = engine.state

    def run_cascade(
        self,
        initial_trigger: str = "manual",
        max_depth: int = 10,
        overload_threshold_pct: float = 100.0,
        generator_trip_frequency_hz: float = 49.0,
    ) -> CascadeResult:
        """
        Run a full cascading failure simulation.

        Args:
            initial_trigger: Description of what started the cascade.
            max_depth: Maximum number of cascade iterations.
            overload_threshold_pct: Lines above this loading % auto-trip.
            generator_trip_frequency_hz: Generators trip below this frequency.

        Returns:
            CascadeResult with full cascade timeline.
        """
        result = CascadeResult(initial_trigger=initial_trigger)
        all_affected_regions = set()

        initial_gen = self.state.total_generation_mw
        initial_demand = self.state.total_demand_mw

        for depth in range(1, max_depth + 1):
            # 1. Find overloaded lines
            overloaded = [
                l for l in self.state.lines.values()
                if l.is_active and l.loading_pct > overload_threshold_pct
            ]

            # 2. Check for under-frequency generator trips
            freq_trips = []
            if self.state.frequency_hz < generator_trip_frequency_hz:
                # Trip the smallest generators first (under-frequency load shedding)
                online_gens = sorted(
                    [g for g in self.state.generators.values() if g.is_online],
                    key=lambda g: g.current_output_mw,
                )
                # Trip up to 10% of generators per cascade step
                n_to_trip = max(1, len(online_gens) // 10)
                freq_trips = online_gens[:n_to_trip]

            if not overloaded and not freq_trips:
                break  # System stabilized

            # 3. Record pre-trip state
            overloaded_before = len(overloaded)

            # 4. Trip overloaded lines
            tripped_lines = []
            for line in overloaded:
                regions = {line.from_node, line.to_node}
                all_affected_regions.update(regions)

                line.is_active = False
                self.engine._redistribute_flow(line)
                tripped_lines.append(line.id)
                line.current_flow_mw = 0.0

            # 5. Trip under-frequency generators
            tripped_gens = []
            for gen in freq_trips:
                all_affected_regions.add(gen.region)
                lost = gen.current_output_mw
                gen.is_online = False
                gen.current_output_mw = 0.0
                self.state.frequency_hz -= (lost / 1000.0) * 0.1
                tripped_gens.append(gen.id)

            # 6. Check for generator isolation
            self.engine._check_generator_isolation()

            # 7. Update frequency based on new deficit
            if self.state.total_demand_mw > 0:
                imbalance_ratio = self.state.deficit_mw / self.state.total_demand_mw
                self.state.frequency_hz = max(
                    45.0,  # Absolute floor
                    50.0 - (imbalance_ratio * 5.0)
                )

            # 8. Record this cascade step
            overloaded_after = len(self.state.overloaded_lines)
            step = CascadeStep(
                depth=depth,
                tripped_lines=tripped_lines,
                tripped_generators=tripped_gens,
                overloaded_lines_before=overloaded_before,
                overloaded_lines_after=overloaded_after,
                total_generation_mw=self.state.total_generation_mw,
                total_demand_mw=self.state.total_demand_mw,
                deficit_mw=self.state.deficit_mw,
                frequency_hz=self.state.frequency_hz,
                affected_regions=list(all_affected_regions),
            )
            result.steps.append(step)

            # 9. Check for total blackout
            if self.state.total_generation_mw <= 0:
                result.blackout = True
                break

        # Compile final result
        result.cascade_depth = len(result.steps)
        result.cascade_size = sum(
            len(s.tripped_lines) + len(s.tripped_generators) for s in result.steps
        )
        result.affected_regions = list(all_affected_regions)
        result.geographic_spread = len(all_affected_regions)
        result.final_deficit_mw = self.state.deficit_mw
        result.final_frequency_hz = self.state.frequency_hz
        result.total_generation_lost_mw = max(0, initial_gen - self.state.total_generation_mw)
        result.total_load_lost_mw = result.final_deficit_mw
        result.system_stable = len(self.state.overloaded_lines) == 0 and not result.blackout

        # Generate recovery recommendations
        result.recovery_actions = self._recommend_recovery(result)

        return result

    def _recommend_recovery(self, result: CascadeResult) -> List[str]:
        """Generate recovery action recommendations based on cascade result."""
        actions = []

        if result.blackout:
            actions.append("CRITICAL: Initiate black start procedure")
            actions.append("Prioritize nuclear and hydro units for restart")
            actions.append("Request maximum emergency imports from all interconnections")
            return actions

        if result.final_deficit_mw > 0:
            actions.append(f"Redispatch {result.final_deficit_mw:.0f} MW from available reserves")

            # Check which technologies have spare capacity
            for gen in self.state.generators.values():
                if gen.is_online and gen.available_reserve_mw > 100:
                    actions.append(
                        f"Ramp up {gen.id} ({gen.technology}): "
                        f"+{gen.available_reserve_mw:.0f} MW available"
                    )

        if result.final_frequency_hz < 49.5:
            actions.append(f"URGENT: Frequency at {result.final_frequency_hz:.2f} Hz — activate frequency reserves")

        if result.geographic_spread >= 3:
            actions.append(f"Wide-area event ({result.geographic_spread} regions) — coordinate with TSO")

        total_import_capacity = sum(self.state.interconnections.values())
        if total_import_capacity > 0 and result.final_deficit_mw > 0:
            actions.append(f"Emergency import capacity available: {total_import_capacity:.0f} MW")

        return actions

    def to_dict(self, result: CascadeResult) -> dict:
        """Serialize a CascadeResult to a JSON-friendly dict."""
        return {
            "initial_trigger": result.initial_trigger,
            "cascade_depth": result.cascade_depth,
            "cascade_size": result.cascade_size,
            "geographic_spread": result.geographic_spread,
            "affected_regions": result.affected_regions,
            "final_deficit_mw": round(result.final_deficit_mw, 1),
            "final_frequency_hz": round(result.final_frequency_hz, 3),
            "total_generation_lost_mw": round(result.total_generation_lost_mw, 1),
            "total_load_lost_mw": round(result.total_load_lost_mw, 1),
            "system_stable": result.system_stable,
            "blackout": result.blackout,
            "recovery_actions": result.recovery_actions,
            "steps": [
                {
                    "depth": s.depth,
                    "tripped_lines": s.tripped_lines,
                    "tripped_generators": s.tripped_generators,
                    "overloaded_lines_before": s.overloaded_lines_before,
                    "overloaded_lines_after": s.overloaded_lines_after,
                    "generation_mw": round(s.total_generation_mw, 1),
                    "demand_mw": round(s.total_demand_mw, 1),
                    "deficit_mw": round(s.deficit_mw, 1),
                    "frequency_hz": round(s.frequency_hz, 3),
                    "affected_regions": s.affected_regions,
                }
                for s in result.steps
            ],
        }
