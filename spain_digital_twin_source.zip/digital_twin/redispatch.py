"""
Redispatch Engine — Acts as the grid operator.

When a deficit occurs after chaos injection, the engine logically brings
reserve capacity online to re-balance the grid, following a merit order:
  1. Hydro (fastest ramp)
  2. Gas / CCGT
  3. Coal
  4. Emergency imports (France, Portugal, Morocco)

Tracks redispatch costs and interconnection import limits.
"""

from typing import Dict, List, Tuple
from .simulator import GridState, Generator


# Approximate marginal cost per MWh by technology (EUR/MWh)
TECH_COSTS = {
    "Hydro": 5.0,
    "Nuclear": 12.0,
    "Wind": 0.0,
    "Solar": 0.0,
    "Gas": 65.0,
    "Coal": 85.0,
    "Import": 90.0,
}

# Interconnection import limits (MW) per border
INTERCONNECTION_LIMITS = {
    "France": 2800.0,
    "Portugal": 3100.0,
    "Morocco": 900.0,
    "Andorra": 50.0,
}


class RedispatchEngine:
    """
    Acts as the grid operator. When a deficit occurs, it logically brings
    reserve capacity online to re-balance the grid.
    """

    def __init__(self, dispatch_order: list = None):
        # The priority order for turning on reserve plants.
        # Hydro is fastest, then Gas (CCGT), then Coal, then Imports.
        self.dispatch_order = dispatch_order or ["Hydro", "Gas", "Coal", "Import"]

    def execute_redispatch(self, state: GridState) -> dict:
        """
        Attempts to serve any generation deficit by ramping up available reserves.
        Modifies the state in-place and returns a detailed log of actions.
        """
        actions_taken = []
        total_cost_eur = 0.0
        deficit = state.deficit_mw

        if deficit <= 0:
            return {
                "status": "Grid Balanced",
                "deficit_before_mw": 0.0,
                "deficit_after_mw": 0.0,
                "total_cost_eur": 0.0,
                "actions": [],
            }

        initial_deficit = deficit

        for tech in self.dispatch_order:
            if deficit <= 0:
                break

            if tech == "Import":
                # Handle imports separately through interconnections
                import_result = self._pull_emergency_imports(state, deficit)
                deficit -= import_result["imported_mw"]
                total_cost_eur += import_result["cost_eur"]
                if import_result["imported_mw"] > 0:
                    actions_taken.append(import_result)
                continue

            # Find all online generators matching this technology with spare capacity
            available_gens = sorted(
                [
                    g for g in state.generators.values()
                    if g.is_online
                    and g.technology == tech
                    and g.available_reserve_mw > 0
                ],
                key=lambda g: g.available_reserve_mw,
                reverse=True,  # Biggest reserves first
            )

            for gen in available_gens:
                if deficit <= 0:
                    break

                ramp_amount = min(deficit, gen.available_reserve_mw)
                gen.current_output_mw += ramp_amount
                deficit -= ramp_amount

                cost = ramp_amount * TECH_COSTS.get(tech, 50.0)
                total_cost_eur += cost

                actions_taken.append({
                    "type": "ramp_up",
                    "generator_id": gen.id,
                    "technology": tech,
                    "region": gen.region,
                    "ramped_mw": round(ramp_amount, 1),
                    "new_output_mw": round(gen.current_output_mw, 1),
                    "cost_eur": round(cost, 0),
                })

        # Update frequency based on remaining deficit
        if state.total_demand_mw > 0 and deficit > 0:
            imbalance = deficit / state.total_demand_mw
            state.frequency_hz = max(47.0, 50.0 - imbalance * 5.0)
        elif deficit <= 0:
            # Frequency recovering
            state.frequency_hz = min(50.0, state.frequency_hz + 0.2)

        return {
            "status": "Redispatch Complete" if deficit <= 0 else "Unserved Energy Remains",
            "deficit_before_mw": round(initial_deficit, 1),
            "deficit_after_mw": round(max(0, deficit), 1),
            "total_cost_eur": round(total_cost_eur, 0),
            "actions": actions_taken,
        }

    def _pull_emergency_imports(self, state: GridState, deficit: float) -> dict:
        """Pull emergency imports from interconnections up to their limits."""
        total_imported = 0.0
        total_cost = 0.0
        sources = {}

        for country, capacity in state.interconnections.items():
            if deficit <= 0:
                break

            # Assume current utilization is proportional to existing imports
            available = capacity * 0.7  # Reserve 30% for stability margin
            pullable = min(deficit, available)

            if pullable > 0:
                state.imports_mw += pullable
                deficit -= pullable
                total_imported += pullable
                cost = pullable * TECH_COSTS["Import"]
                total_cost += cost
                sources[country] = round(pullable, 1)

        return {
            "type": "emergency_import",
            "imported_mw": round(total_imported, 1),
            "cost_eur": round(total_cost, 0),
            "sources": sources,
        }

    def estimate_redispatch_cost(self, state: GridState) -> dict:
        """Estimate the cost to fully redispatch without modifying state."""
        import copy
        test_state = copy.deepcopy(state)
        result = self.execute_redispatch(test_state)
        return {
            "estimated_cost_eur": result["total_cost_eur"],
            "can_fully_serve": result["deficit_after_mw"] <= 0,
            "remaining_deficit_mw": result["deficit_after_mw"],
        }
