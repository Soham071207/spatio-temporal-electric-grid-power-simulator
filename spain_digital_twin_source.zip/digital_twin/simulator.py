"""
Grid Chaos Engine — The core engine for injecting failures into the Digital Twin.

Implements 7 chaos modes from the design doc:
  🐒 Grid Chaos Monkey   — Single random component outage
  🌪️ Storm Mode          — Multiple geographically correlated failures
  ☀️ Renewable Shock     — Sudden wind/solar generation reduction
  🔥 Demand Surge        — Sudden increase in electricity demand
  🔌 Island Mode         — Disconnect an interconnection
  💥 Cascade Mode        — Failure → secondary → tertiary failures
  🧠 AI Attack           — GNN chooses most vulnerable component
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum
import copy
import random
import math


class ChaosMode(Enum):
    RANDOM = "random"           # 🐒 Grid Chaos Monkey
    STORM = "storm"             # 🌪️ Storm Mode
    RENEWABLE_SHOCK = "renewable_shock"  # ☀️ Renewable Shock
    DEMAND_SURGE = "demand_surge"        # 🔥 Demand Surge
    ISLAND = "island"           # 🔌 Island Mode
    CASCADE = "cascade"         # 💥 Cascade Mode
    AI_ATTACK = "ai_attack"     # 🧠 AI Attack


@dataclass
class Generator:
    """Represents a power plant in the grid."""
    id: str
    technology: str             # Hydro, Gas, Coal, Nuclear, Wind, Solar, Import
    region: str
    installed_capacity_mw: float
    current_output_mw: float
    is_online: bool = True
    lat: float = 0.0
    lon: float = 0.0

    @property
    def available_reserve_mw(self) -> float:
        if not self.is_online:
            return 0.0
        return max(0.0, self.installed_capacity_mw - self.current_output_mw)

    @property
    def load_factor(self) -> float:
        if self.installed_capacity_mw <= 0:
            return 0.0
        return self.current_output_mw / self.installed_capacity_mw


@dataclass
class TransmissionLine:
    """Represents a transmission line (edge) in the grid graph."""
    id: str
    from_node: str
    to_node: str
    capacity_mw: float
    current_flow_mw: float = 0.0
    is_active: bool = True

    @property
    def loading_pct(self) -> float:
        if self.capacity_mw <= 0:
            return 0.0
        return (abs(self.current_flow_mw) / self.capacity_mw) * 100.0

    @property
    def is_overloaded(self) -> bool:
        return self.loading_pct > 100.0


@dataclass
class GridState:
    """
    Complete snapshot of the grid at a point in time.
    This is the central data structure that all modules operate on.
    """
    timestamp: str = ""
    generators: Dict[str, Generator] = field(default_factory=dict)
    lines: Dict[str, TransmissionLine] = field(default_factory=dict)
    regional_demand_mw: Dict[str, float] = field(default_factory=dict)
    imports_mw: float = 0.0
    frequency_hz: float = 50.0     # Nominal frequency

    # Interconnection capacities (MW) — Spain's borders
    interconnections: Dict[str, float] = field(default_factory=lambda: {
        "France": 2800.0,
        "Portugal": 3100.0,
        "Morocco": 900.0,
        "Andorra": 50.0,
    })

    @property
    def total_demand_mw(self) -> float:
        return sum(self.regional_demand_mw.values())

    @property
    def total_generation_mw(self) -> float:
        return sum(g.current_output_mw for g in self.generators.values() if g.is_online)

    @property
    def total_capacity_mw(self) -> float:
        return sum(g.installed_capacity_mw for g in self.generators.values() if g.is_online)

    @property
    def deficit_mw(self) -> float:
        return max(0.0, self.total_demand_mw - self.total_generation_mw - self.imports_mw)

    @property
    def reserve_capacity_mw(self) -> float:
        return max(0.0, self.total_capacity_mw - self.total_generation_mw)

    @property
    def reserve_margin_pct(self) -> float:
        if self.total_demand_mw <= 0:
            return 100.0
        return (self.reserve_capacity_mw / self.total_demand_mw) * 100.0

    @property
    def overloaded_lines(self) -> List[TransmissionLine]:
        return [l for l in self.lines.values() if l.is_active and l.is_overloaded]

    @property
    def offline_generators(self) -> List[Generator]:
        return [g for g in self.generators.values() if not g.is_online]

    def generation_by_technology(self) -> Dict[str, float]:
        """Aggregate generation by fuel type."""
        by_tech = {}
        for g in self.generators.values():
            if g.is_online:
                by_tech[g.technology] = by_tech.get(g.technology, 0.0) + g.current_output_mw
        return by_tech

    def summary(self) -> dict:
        """Human-readable summary of the grid state."""
        return {
            "timestamp": self.timestamp,
            "total_demand_mw": round(self.total_demand_mw, 1),
            "total_generation_mw": round(self.total_generation_mw, 1),
            "imports_mw": round(self.imports_mw, 1),
            "deficit_mw": round(self.deficit_mw, 1),
            "reserve_margin_pct": round(self.reserve_margin_pct, 1),
            "frequency_hz": round(self.frequency_hz, 3),
            "online_generators": sum(1 for g in self.generators.values() if g.is_online),
            "offline_generators": len(self.offline_generators),
            "active_lines": sum(1 for l in self.lines.values() if l.is_active),
            "overloaded_lines": len(self.overloaded_lines),
            "generation_mix": {k: round(v, 1) for k, v in self.generation_by_technology().items()},
        }


@dataclass
class ChaosEvent:
    """Records a single chaos injection event."""
    mode: str
    target_id: str
    target_type: str            # "generator", "line", "region", "interconnection"
    description: str
    impact_mw: float = 0.0
    cascade_depth: int = 0
    cascade_size: int = 0


class ChaosEngine:
    """
    The Grid Chaos Engine — injects controlled failures into the Digital Twin
    and simulates the grid's response.

    Supports all 7 chaos modes from the design document.
    """

    def __init__(self, initial_state: GridState):
        self._initial_state = copy.deepcopy(initial_state)
        self.state = copy.deepcopy(initial_state)
        self.event_log: List[ChaosEvent] = []
        self.cascade_log: List[dict] = []

    # ──────────────────────────────────────────────
    #  CHAOS INJECTION METHODS
    # ──────────────────────────────────────────────

    def inject_generator_failure(self, generator_id: str) -> ChaosEvent:
        """🐒 Trip a power plant offline."""
        if generator_id not in self.state.generators:
            raise ValueError(f"Generator '{generator_id}' not found in grid state.")

        gen = self.state.generators[generator_id]
        if not gen.is_online:
            raise ValueError(f"Generator '{generator_id}' is already offline.")

        lost_mw = gen.current_output_mw
        gen.is_online = False
        gen.current_output_mw = 0.0

        # Frequency impact: approx -0.1 Hz per 1000 MW lost
        self.state.frequency_hz -= (lost_mw / 1000.0) * 0.1

        event = ChaosEvent(
            mode=ChaosMode.RANDOM.value,
            target_id=generator_id,
            target_type="generator",
            description=f"Generator '{generator_id}' ({gen.technology}) tripped offline. Lost {lost_mw:.0f} MW.",
            impact_mw=lost_mw,
        )
        self.event_log.append(event)
        return event

    def inject_line_outage(self, line_id: str) -> ChaosEvent:
        """🔌 Remove a transmission line from service."""
        if line_id not in self.state.lines:
            raise ValueError(f"Transmission line '{line_id}' not found.")

        line = self.state.lines[line_id]
        if not line.is_active:
            raise ValueError(f"Line '{line_id}' is already out of service.")

        lost_flow = line.current_flow_mw
        line.is_active = False
        line.current_flow_mw = 0.0

        # Redistribute the flow to remaining parallel lines
        self._redistribute_flow(line)

        event = ChaosEvent(
            mode=ChaosMode.RANDOM.value,
            target_id=line_id,
            target_type="line",
            description=f"Transmission line '{line_id}' ({line.from_node}→{line.to_node}) tripped. Was carrying {lost_flow:.0f} MW.",
            impact_mw=abs(lost_flow),
        )
        self.event_log.append(event)
        return event

    def inject_renewable_shock(self, fuel_type: str, reduction_pct: float) -> ChaosEvent:
        """☀️ Reduce all generators of a renewable type by a percentage."""
        fuel_type_lower = fuel_type.lower()
        total_lost = 0.0
        affected = 0

        for gen in self.state.generators.values():
            if gen.is_online and gen.technology.lower() == fuel_type_lower:
                reduction = gen.current_output_mw * (reduction_pct / 100.0)
                gen.current_output_mw -= reduction
                total_lost += reduction
                affected += 1

        # Frequency impact
        self.state.frequency_hz -= (total_lost / 1000.0) * 0.1

        event = ChaosEvent(
            mode=ChaosMode.RENEWABLE_SHOCK.value,
            target_id=fuel_type,
            target_type="generator",
            description=f"Renewable shock: {fuel_type} generation reduced by {reduction_pct}%. "
                        f"Affected {affected} plants, lost {total_lost:.0f} MW.",
            impact_mw=total_lost,
        )
        self.event_log.append(event)
        return event

    def inject_demand_surge(self, region: str, increase_pct: float) -> ChaosEvent:
        """🔥 Spike demand in a specific region."""
        if region not in self.state.regional_demand_mw:
            raise ValueError(f"Region '{region}' not found in grid state.")

        current = self.state.regional_demand_mw[region]
        surge = current * (increase_pct / 100.0)
        self.state.regional_demand_mw[region] = current + surge

        # Frequency impact from sudden demand increase
        self.state.frequency_hz -= (surge / 1000.0) * 0.05

        event = ChaosEvent(
            mode=ChaosMode.DEMAND_SURGE.value,
            target_id=region,
            target_type="region",
            description=f"Demand surge in {region}: +{increase_pct}% (+{surge:.0f} MW). "
                        f"New demand: {current + surge:.0f} MW.",
            impact_mw=surge,
        )
        self.event_log.append(event)
        return event

    def inject_interconnection_failure(self, country: str) -> ChaosEvent:
        """🔌 Island mode — disconnect an international interconnection."""
        if country not in self.state.interconnections:
            raise ValueError(f"Interconnection with '{country}' not found.")

        lost_capacity = self.state.interconnections[country]
        self.state.interconnections[country] = 0.0

        # If we were importing from this country, we lose that power
        import_loss = min(self.state.imports_mw, lost_capacity * 0.3)  # Assume 30% utilization
        self.state.imports_mw = max(0.0, self.state.imports_mw - import_loss)

        event = ChaosEvent(
            mode=ChaosMode.ISLAND.value,
            target_id=country,
            target_type="interconnection",
            description=f"Interconnection with {country} severed. "
                        f"Lost {lost_capacity:.0f} MW capacity, {import_loss:.0f} MW actual imports.",
            impact_mw=import_loss,
        )
        self.event_log.append(event)
        return event

    # ──────────────────────────────────────────────
    #  COMPOUND CHAOS MODES
    # ──────────────────────────────────────────────

    def run_random_chaos(self, n_failures: int = 1) -> List[ChaosEvent]:
        """🐒 Level 1 — Random component failures."""
        events = []
        online_gens = [g for g in self.state.generators.values() if g.is_online]
        active_lines = [l for l in self.state.lines.values() if l.is_active]
        targets = online_gens + active_lines

        if not targets:
            return events

        for _ in range(min(n_failures, len(targets))):
            target = random.choice(targets)
            targets.remove(target)

            if isinstance(target, Generator):
                events.append(self.inject_generator_failure(target.id))
            elif isinstance(target, TransmissionLine):
                events.append(self.inject_line_outage(target.id))

        return events

    def run_targeted_chaos(self) -> List[ChaosEvent]:
        """Level 2 — Attack highest-loaded components."""
        events = []

        # Find the most heavily loaded generator
        online_gens = [g for g in self.state.generators.values() if g.is_online]
        if online_gens:
            biggest = max(online_gens, key=lambda g: g.current_output_mw)
            events.append(self.inject_generator_failure(biggest.id))

        # Find the most heavily loaded line
        active_lines = [l for l in self.state.lines.values() if l.is_active]
        if active_lines:
            most_loaded = max(active_lines, key=lambda l: l.loading_pct)
            events.append(self.inject_line_outage(most_loaded.id))

        return events

    def run_storm_mode(self, region: str, n_failures: int = 3) -> List[ChaosEvent]:
        """🌪️ Multiple geographically correlated failures in one region."""
        events = []

        # Trip generators in the target region
        regional_gens = [
            g for g in self.state.generators.values()
            if g.is_online and g.region.lower() == region.lower()
        ]
        random.shuffle(regional_gens)

        for gen in regional_gens[:n_failures]:
            events.append(self.inject_generator_failure(gen.id))

        # Also trip lines connected to the region
        regional_lines = [
            l for l in self.state.lines.values()
            if l.is_active and (l.from_node.lower() == region.lower() or l.to_node.lower() == region.lower())
        ]
        for line in regional_lines[:max(1, n_failures // 2)]:
            events.append(self.inject_line_outage(line.id))

        return events

    # ──────────────────────────────────────────────
    #  CASCADE SIMULATION
    # ──────────────────────────────────────────────

    def simulate_cascade(self, max_depth: int = 5) -> dict:
        """
        💥 Cascade Mode — Iteratively propagate overloads.

        After an initial fault, check for overloaded lines.
        If a line exceeds 100% capacity, it trips automatically,
        redistributing its flow to remaining lines.
        Continue until stable or total blackout.
        """
        cascade_events = []
        depth = 0

        while depth < max_depth:
            overloaded = self.state.overloaded_lines
            if not overloaded:
                break   # System stabilized

            depth += 1
            tripped_this_round = []

            for line in overloaded:
                event = self.inject_line_outage(line.id)
                event.cascade_depth = depth
                tripped_this_round.append(line.id)
                cascade_events.append({
                    "depth": depth,
                    "line_id": line.id,
                    "loading_pct": line.loading_pct,
                    "flow_mw": line.current_flow_mw,
                })

            # Check if any generators need to trip due to islanding
            self._check_generator_isolation()

        result = {
            "cascade_depth": depth,
            "cascade_size": len(cascade_events),
            "events": cascade_events,
            "final_deficit_mw": self.state.deficit_mw,
            "final_frequency_hz": self.state.frequency_hz,
            "system_stable": len(self.state.overloaded_lines) == 0,
            "blackout": self.state.total_generation_mw <= 0,
        }
        self.cascade_log.append(result)
        return result

    # ──────────────────────────────────────────────
    #  WHAT-IF SIMULATOR
    # ──────────────────────────────────────────────

    def what_if(self, scenario_fn) -> dict:
        """
        Compare grid state before and after a scenario.
        scenario_fn should be a callable that takes the ChaosEngine as argument.

        Returns a before/after comparison dict.
        """
        before = self.state.summary()

        # Run the scenario
        scenario_fn(self)

        after = self.state.summary()

        # Build comparison
        comparison = {"before": before, "after": after, "deltas": {}}
        for key in before:
            if isinstance(before[key], (int, float)):
                comparison["deltas"][key] = round(after[key] - before[key], 2)

        return comparison

    # ──────────────────────────────────────────────
    #  STATE MANAGEMENT
    # ──────────────────────────────────────────────

    def reset(self):
        """Restore the grid to its initial pre-chaos state."""
        self.state = copy.deepcopy(self._initial_state)
        self.event_log.clear()
        self.cascade_log.clear()

    def get_state(self) -> GridState:
        """Return the current grid state."""
        return self.state

    def get_initial_state(self) -> GridState:
        """Return the initial (pre-chaos) state."""
        return self._initial_state

    def get_event_log(self) -> List[dict]:
        """Return a serializable event log."""
        return [
            {
                "mode": e.mode,
                "target_id": e.target_id,
                "target_type": e.target_type,
                "description": e.description,
                "impact_mw": round(e.impact_mw, 1),
                "cascade_depth": e.cascade_depth,
            }
            for e in self.event_log
        ]

    # ──────────────────────────────────────────────
    #  INTERNAL HELPERS
    # ──────────────────────────────────────────────

    def _redistribute_flow(self, tripped_line: TransmissionLine):
        """
        When a line trips, redistribute its flow among parallel active lines.
        If no parallel lines exist, the flow is lost (contributing to deficit).
        """
        parallel_lines = [
            l for l in self.state.lines.values()
            if l.is_active
            and l.id != tripped_line.id
            and (
                (l.from_node == tripped_line.from_node and l.to_node == tripped_line.to_node)
                or (l.from_node == tripped_line.to_node and l.to_node == tripped_line.from_node)
            )
        ]

        if not parallel_lines:
            # No parallel path — distribute evenly among all active lines
            active = [l for l in self.state.lines.values() if l.is_active]
            if active:
                share = abs(tripped_line.current_flow_mw) / len(active)
                for l in active:
                    l.current_flow_mw += share
            return

        share = abs(tripped_line.current_flow_mw) / len(parallel_lines)
        for l in parallel_lines:
            l.current_flow_mw += share

    def _check_generator_isolation(self):
        """
        If all lines from a generator's region are down,
        the generator is effectively islanded and must trip.
        """
        for gen in self.state.generators.values():
            if not gen.is_online:
                continue

            # Check if any active line connects to this generator's region
            has_connection = any(
                l.is_active and (l.from_node == gen.region or l.to_node == gen.region)
                for l in self.state.lines.values()
            )

            if not has_connection and self.state.lines:
                gen.is_online = False
                gen.current_output_mw = 0.0


def build_demo_grid_state() -> GridState:
    """
    Build a realistic demo GridState based on Spain's actual energy mix.
    Uses approximate 2024 capacity and generation figures.
    """
    state = GridState(timestamp="2025-08-15T14:00:00")

    # Regional demand (MW) — approximate summer afternoon
    state.regional_demand_mw = {
        "Andalucía": 4200.0,
        "Aragón": 900.0,
        "Asturias": 600.0,
        "Baleares": 450.0,
        "Canarias": 550.0,
        "Cantabria": 350.0,
        "Castilla y León": 1400.0,
        "Castilla-La Mancha": 1200.0,
        "Cataluña": 3800.0,
        "Comunidad Valenciana": 3200.0,
        "Extremadura": 600.0,
        "Galicia": 1500.0,
        "Madrid": 4500.0,
        "Murcia": 850.0,
        "Navarra": 400.0,
        "País Vasco": 1200.0,
        "La Rioja": 200.0,
        "Ceuta": 30.0,
        "Melilla": 25.0,
    }

    # Generators — representative sample of Spain's fleet
    generators = [
        # Nuclear
        Generator("NUC_Almaraz_1", "Nuclear", "Extremadura", 1050, 980),
        Generator("NUC_Almaraz_2", "Nuclear", "Extremadura", 1050, 1020),
        Generator("NUC_Cofrentes", "Nuclear", "Comunidad Valenciana", 1092, 1050),
        Generator("NUC_Vandellos_2", "Nuclear", "Cataluña", 1087, 1060),
        Generator("NUC_Trillo", "Nuclear", "Castilla-La Mancha", 1066, 1040),
        Generator("NUC_Asco_1", "Nuclear", "Cataluña", 1033, 1000),
        Generator("NUC_Asco_2", "Nuclear", "Cataluña", 1027, 990),
        # Gas (CCGT)
        Generator("GAS_Castellon", "Gas", "Comunidad Valenciana", 1200, 850),
        Generator("GAS_Arcos", "Gas", "Andalucía", 800, 600),
        Generator("GAS_Bahia_Bizkaia", "Gas", "País Vasco", 800, 450),
        Generator("GAS_SanRoque", "Gas", "Andalucía", 800, 500),
        Generator("GAS_Tarragona", "Gas", "Cataluña", 850, 700),
        Generator("GAS_Sagunto", "Gas", "Comunidad Valenciana", 1200, 400),
        Generator("GAS_PtoBolloqui", "Gas", "Madrid", 1200, 800),
        # Wind
        Generator("WIND_CastillaLeon", "Wind", "Castilla y León", 5800, 2200),
        Generator("WIND_Aragon", "Wind", "Aragón", 4200, 1600),
        Generator("WIND_Galicia", "Wind", "Galicia", 3800, 1400),
        Generator("WIND_Andalucia", "Wind", "Andalucía", 3600, 900),
        Generator("WIND_CastillaMancha", "Wind", "Castilla-La Mancha", 3800, 1500),
        Generator("WIND_Navarra", "Wind", "Navarra", 1100, 380),
        # Solar
        Generator("SOLAR_Extremadura", "Solar", "Extremadura", 4500, 3800),
        Generator("SOLAR_CastillaMancha", "Solar", "Castilla-La Mancha", 4200, 3500),
        Generator("SOLAR_Andalucia", "Solar", "Andalucía", 4000, 3200),
        Generator("SOLAR_Murcia", "Solar", "Murcia", 2200, 1900),
        Generator("SOLAR_Aragon", "Solar", "Aragón", 1800, 1500),
        # Hydro
        Generator("HYDRO_Galicia", "Hydro", "Galicia", 3500, 800),
        Generator("HYDRO_CastillaLeon", "Hydro", "Castilla y León", 2800, 600),
        Generator("HYDRO_Aragon", "Hydro", "Aragón", 1800, 400),
        Generator("HYDRO_Cataluña", "Hydro", "Cataluña", 1500, 350),
        Generator("HYDRO_Extremadura", "Hydro", "Extremadura", 2200, 500),
        # Coal (minimal remaining)
        Generator("COAL_Asturias", "Coal", "Asturias", 600, 200),
    ]

    for gen in generators:
        state.generators[gen.id] = gen

    # Transmission lines — major corridors
    lines = [
        TransmissionLine("L_Madrid_Castilla", "Madrid", "Castilla y León", 3000, 1200),
        TransmissionLine("L_Madrid_CMancha", "Madrid", "Castilla-La Mancha", 3500, 1800),
        TransmissionLine("L_Madrid_Valencia", "Madrid", "Comunidad Valenciana", 2500, 900),
        TransmissionLine("L_Cataluña_Aragon", "Cataluña", "Aragón", 2200, 1100),
        TransmissionLine("L_Cataluña_Valencia", "Cataluña", "Comunidad Valenciana", 2000, 800),
        TransmissionLine("L_Andalucia_Extremadura", "Andalucía", "Extremadura", 2000, 1500),
        TransmissionLine("L_Andalucia_CMancha", "Andalucía", "Castilla-La Mancha", 1800, 700),
        TransmissionLine("L_Andalucia_Murcia", "Andalucía", "Murcia", 1200, 400),
        TransmissionLine("L_Galicia_Asturias", "Galicia", "Asturias", 1500, 600),
        TransmissionLine("L_Galicia_CastillaLeon", "Galicia", "Castilla y León", 2000, 900),
        TransmissionLine("L_PVasco_Navarra", "País Vasco", "Navarra", 1200, 350),
        TransmissionLine("L_PVasco_Cantabria", "País Vasco", "Cantabria", 800, 200),
        TransmissionLine("L_CastillaLeon_Asturias", "Castilla y León", "Asturias", 1200, 400),
        TransmissionLine("L_Valencia_Murcia", "Comunidad Valenciana", "Murcia", 1000, 300),
        TransmissionLine("L_Aragon_Navarra", "Aragón", "Navarra", 1000, 250),
        TransmissionLine("L_Cataluña_France", "Cataluña", "France", 2800, 1200),
        TransmissionLine("L_Extremadura_Portugal", "Extremadura", "Portugal", 3100, 800),
        TransmissionLine("L_Andalucia_Morocco", "Andalucía", "Morocco", 900, 200),
    ]

    for line in lines:
        state.lines[line.id] = line

    # Imports
    state.imports_mw = 1200.0  # Net imports from France mainly

    return state
