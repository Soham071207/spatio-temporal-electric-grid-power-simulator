import os
import pandas as pd
import numpy as np
import logging
from glob import glob
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Base populations for weighting
POPULATION = {
    'Andalucía': 8500000,
    'Cataluña': 7800000,
    'Comunidad de Madrid': 6800000,
    'Comunidad Valenciana': 5100000,
    'Galicia': 2700000,
    'Castilla y León': 2400000,
    'País Vasco': 2200000,
    'Canarias': 2200000,
    'Castilla-La Mancha': 2100000,
    'Región de Murcia': 1500000,
    'Aragón': 1300000,
    'Islas Baleares': 1200000,
    'Extremadura': 1050000,
    'Principado de Asturias': 1000000,
    'Comunidad Foral de Navarra': 660000,
    'Cantabria': 580000,
    'La Rioja': 320000,
    'Melilla': 85000,
    'Ceuta': 84000
}

# The names in e-sios might have encoding artifacts depending on OS/download. 
# We'll map them carefully.
ESIOS_TO_STD = {
    'Andaluca': 'Andalucía',
    'Aragn': 'Aragón',
    'Cantabria': 'Cantabria',
    'Castilla y Len': 'Castilla y León',
    'Castilla-La Mancha': 'Castilla-La Mancha',
    'Catalua': 'Cataluña',
    'Ceuta': 'Ceuta',
    'Comunidad Foral de Navarra': 'Comunidad Foral de Navarra',
    'Comunidad Valenciana': 'Comunidad Valenciana',
    'Comunidad de Madrid': 'Comunidad de Madrid',
    'Extremadura': 'Extremadura',
    'Galicia': 'Galicia',
    'Islas Baleares': 'Islas Baleares',
    'Islas Canarias': 'Canarias',
    'La Rioja': 'La Rioja',
    'Melilla': 'Melilla',
    'Pas Vasco': 'País Vasco',
    'Principado de Asturias': 'Principado de Asturias',
    'Regin de Murcia': 'Región de Murcia'
}

def load_weather_data(weather_dir="data/processed/weather"):
    """Loads and returns weather data as a dictionary of DataFrames."""
    weather_data = {}
    files = glob(os.path.join(weather_dir, "*.csv"))
    for f in files:
        region = os.path.basename(f).replace(".csv", "").replace("_", " ")
        # Handle some basic name mapping if needed
        if region == "Cataluna": region = "Cataluña"
        if region == "Andalucia": region = "Andalucía"
        if region == "Aragon": region = "Aragón"
        if region == "Pais Vasco": region = "País Vasco"
        
        df = pd.read_csv(f)
        if 'time' in df.columns:
            df['datetime'] = pd.to_datetime(df['time']).dt.tz_localize(None)
            df = df.set_index('datetime')
            weather_data[region] = df
            
    return weather_data

def compute_hourly_weights(df_weather, region, national_datetime):
    """
    Computes dynamic hourly weights based on population, temperature, and solar.
    Weight = BasePop * (1 + HDD_factor + CDD_factor) * (1 - Solar_factor)
    """
    base_weight = POPULATION.get(region, 0)
    
    # If we don't have weather for some reason, just return constant base weight
    if region not in df_weather:
        return pd.Series(base_weight, index=national_datetime)
        
    wdf = df_weather[region].reindex(national_datetime)
    
    # Heating Degree Deviation (Heating needed when temp < 15C)
    hdd = np.maximum(0, 15 - wdf['temperature_2m'].fillna(15))
    hdd_factor = (hdd / 10.0) * 0.05  # 5% demand increase per 10 degrees below 15
    
    # Cooling Degree Deviation (Cooling needed when temp > 24C)
    cdd = np.maximum(0, wdf['temperature_2m'].fillna(24) - 24)
    cdd_factor = (cdd / 10.0) * 0.08  # 8% demand increase per 10 degrees above 24
    
    # Solar effect (Reduces lighting load)
    # shortwave_radiation max is around 1000 W/m2
    solar = wdf['shortwave_radiation'].fillna(0)
    solar_factor = (solar / 1000.0) * 0.02 # 2% demand reduction at peak solar
    
    dynamic_weights = base_weight * (1 + hdd_factor + cdd_factor) * (1 - solar_factor)
    return dynamic_weights

def disaggregate():
    logging.info("Starting demand disaggregation...")
    
    telemetry_dir = "data/processed/grid_telemetry"
    national_file = os.path.join(telemetry_dir, "demand_national.csv")
    monthly_file = os.path.join(telemetry_dir, "demand_ccaa_monthly.csv")
    
    if not os.path.exists(national_file) or not os.path.exists(monthly_file):
        logging.error("Missing telemetry files. Please run download_grid_data.py first.")
        return
        
    df_nat = pd.read_csv(national_file)
    df_nat['datetime'] = pd.to_datetime(df_nat['datetime'])
    df_nat = df_nat.set_index('datetime').sort_index()
    
    df_mon = pd.read_csv(monthly_file)
    df_mon['datetime'] = pd.to_datetime(df_mon['datetime'])
    
    weather_data = load_weather_data()
    
    # Map raw e-sios geo names to our standard ones
    if 'geo_name' in df_mon.columns:
        df_mon['region'] = df_mon['geo_name'].apply(lambda x: ESIOS_TO_STD.get(x, x))
    
    disaggregated_dfs = []
    
    regions = df_mon['region'].dropna().unique()
    for region in regions:
        logging.info(f"Disaggregating {region}...")
        
        region_monthly = df_mon[df_mon['region'] == region]
        
        # We will build it month by month to apply the volume constraint
        for _, row in region_monthly.iterrows():
            dt_raw = row['datetime']
            # e-sios monthly data often stamps at the end of previous month or weird UTC offsets
            # e.g., '2023-12-31 23:00:00' represents January 2024. 
            # So if day is > 15, it's actually representing the next month.
            target_year = dt_raw.year
            target_month = dt_raw.month
            if dt_raw.day > 15:
                if target_month == 12:
                    target_month = 1
                    target_year += 1
                else:
                    target_month += 1
                    
            month_start = datetime(target_year, target_month, 1)
            
            if target_month == 12:
                month_end = datetime(target_year + 1, 1, 1) - pd.Timedelta(hours=1)
            else:
                month_end = datetime(target_year, target_month + 1, 1) - pd.Timedelta(hours=1)
                
            # Get national hourly curve for this month
            nat_mask = (df_nat.index >= month_start) & (df_nat.index <= month_end)
            nat_month = df_nat.loc[nat_mask].copy()
            
            if nat_month.empty:
                continue
                
            target_volume = row['value'] # MWh for the month
            
            # Compute dynamic weights for every hour
            hourly_weights = compute_hourly_weights(weather_data, region, nat_month.index)
            
            # Apply weights to national shape
            # shape = nat_value * weight
            raw_hourly = nat_month['value'] * hourly_weights
            
            # Rescale to match exact monthly volume
            current_volume = raw_hourly.sum()
            if current_volume > 0:
                scale_factor = target_volume / current_volume
                final_hourly = raw_hourly * scale_factor
            else:
                final_hourly = raw_hourly
                
            df_res = pd.DataFrame({
                'datetime': final_hourly.index,
                'region': region,
                'demand_mwh': final_hourly.values
            })
            
            disaggregated_dfs.append(df_res)
            
    if disaggregated_dfs:
        final_df = pd.concat(disaggregated_dfs, ignore_index=True)
        final_df = final_df.sort_values(['region', 'datetime'])
        
        output_path = os.path.join(telemetry_dir, "demand_regional_disaggregated.csv")
        final_df.to_csv(output_path, index=False)
        logging.info(f"Successfully saved {len(final_df)} disaggregated records to {output_path}")
    else:
        logging.error("Failed to produce disaggregated data.")

if __name__ == "__main__":
    disaggregate()
